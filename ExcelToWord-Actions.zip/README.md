# ExcelToWord - 批量生成Word工具

通过GitHub Actions实现Excel数据批量填充Word模板，无需本地安装Python。

## 使用方法

### 1. 准备文件

在你的仓库根目录放入两个文件：
- `template.docx` - Word模板文件（占位符与Excel列名一致）
- `data.xlsx` - Excel数据文件

### 2. 运行工作流

1. 进入仓库的 **Actions** 标签页
2. 选择 **"Excel to Word Batch Generator"** 工作流
3. 点击 **"Run workflow"** 按钮
4. （可选）配置参数：
   - **filename_column**: 用哪一列的值作为文件名（如：`客户姓名`）
   - **filename_pattern**: 自定义文件名模板（如：`报告_{客户姓名}_{序号}`）
5. 点击 **Run**

### 3. 下载结果

工作流运行完成后，在页面底部的 **Artifacts** 区域下载：
- `generated-documents` - 所有生成的Word文件
- `generated-documents-zip` - 打包的zip文件

## 占位符规则

Word模板中可以使用以下三种格式的占位符：

| 格式 | 示例 | 说明 |
|------|------|------|
| 纯文本 | `客户姓名` | 与Excel列名完全一致 |
| 双下划线 | `__客户姓名__` | 传统占位符格式 |
| 花括号 | `{客户姓名}` | 现代占位符格式 |

**注意**：Excel列名会自动清理前后空白字符（如制表符、空格）。

## 本地调试（可选）

如果你想在本地运行：

```bash
pip install python-docx pandas openpyxl
python src/generate.py --template template.docx --excel data.xlsx --output ./output
```

## 文件结构

```
.
├── .github/
│   └── workflows/
│       └── generate.yml    # GitHub Actions配置
├── src/
│   └── generate.py         # 核心生成脚本
├── template.docx           # 你的Word模板（需自行添加）
├── data.xlsx              # 你的Excel数据（需自行添加）
└── README.md
```
