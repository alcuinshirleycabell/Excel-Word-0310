import os
import re
import argparse
import pandas as pd
from docx import Document


def build_mapping(row: pd.Series) -> dict:
    """构建占位符映射，支持三种格式：__字段__、{字段}、纯文本"""
    mapping = {}
    for col, val in row.items():
        col = col.strip()
        v = "" if pd.isna(val) else str(val)
        mapping[f"__{col}__"] = v
        mapping["{" + col + "}"] = v
        mapping[col] = v
    return mapping


def replace_in_paragraph(paragraph, mapping: dict):
    """替换段落中的占位符"""
    full_text = "".join(run.text for run in paragraph.runs)
    if not full_text and not paragraph.runs:
        return False

    new_text = full_text
    for key, value in mapping.items():
        if key in new_text:
            new_text = new_text.replace(key, value)

    if new_text == full_text:
        return False

    if paragraph.runs:
        paragraph.runs[0].text = new_text
        for run in paragraph.runs[1:]:
            run.text = ""
    else:
        paragraph.add_run(new_text)
    return True


def _iter_paragraphs_in_cell(cell):
    for p in cell.paragraphs:
        yield p
    for table in cell.tables:
        for row in table.rows:
            for inner_cell in row.cells:
                yield from _iter_paragraphs_in_cell(inner_cell)


def iter_all_paragraphs(doc: Document):
    for p in doc.paragraphs:
        yield p

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                yield from _iter_paragraphs_in_cell(cell)

    for section in doc.sections:
        for p in section.header.paragraphs:
            yield p
        for table in section.header.tables:
            for row in table.rows:
                for cell in row.cells:
                    yield from _iter_paragraphs_in_cell(cell)
        for p in section.footer.paragraphs:
            yield p
        for table in section.footer.tables:
            for row in table.rows:
                for cell in row.cells:
                    yield from _iter_paragraphs_in_cell(cell)


def replace_in_doc(doc: Document, mapping: dict):
    """替换文档中所有占位符"""
    count = 0
    for paragraph in iter_all_paragraphs(doc):
        if replace_in_paragraph(paragraph, mapping):
            count += 1
    return count


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]+', "_", name).strip()
    return name or "output"


def render_filename(row: pd.Series, idx: int, name_col: str, pattern: str) -> str:
    if pattern:
        rendered = pattern
        for col, val in row.items():
            col = col.strip()
            rendered = rendered.replace("{" + col + "}", str(val or ""))
        rendered = rendered.replace("{序号}", str(idx + 1))
        return sanitize_filename(rendered)

    if name_col:
        name_col = name_col.strip()
        return sanitize_filename(str(row.get(name_col, "")).strip() or f"output_{idx + 1}")

    return f"output_{idx + 1}"


def main():
    parser = argparse.ArgumentParser(description='Excel批量生成Word工具')
    parser.add_argument('--template', required=True, help='Word模板文件路径')
    parser.add_argument('--excel', required=True, help='Excel数据文件路径')
    parser.add_argument('--output', required=True, help='输出目录')
    parser.add_argument('--filename-col', default='', help='用于文件命名的列名')
    parser.add_argument('--filename-pattern', default='', help='文件名模板')
    args = parser.parse_args()

    print(f"读取Excel: {args.excel}")
    df = pd.read_excel(args.excel, dtype=str).fillna("")
    df.columns = [col.strip() for col in df.columns]

    total = len(df)
    print(f"共 {total} 行数据，{len(df.columns)} 列")
    print(f"列名: {', '.join(df.columns[:5])}...")

    os.makedirs(args.output, exist_ok=True)

    for idx, row in df.iterrows():
        mapping = build_mapping(row)

        doc = Document(args.template)
        replace_count = replace_in_doc(doc, mapping)

        base = render_filename(row, idx, args.filename_col, args.filename_pattern)
        out_path = os.path.join(args.output, f"{base}.docx")

        if os.path.exists(out_path):
            out_path = os.path.join(args.output, f"{base}_{idx + 1}.docx")

        doc.save(out_path)
        print(f"[{idx + 1}/{total}] 已生成: {os.path.basename(out_path)} (替换{replace_count}处)")

    print(f"\n全部完成！共生成 {total} 个文件，保存在 {args.output}/")


if __name__ == "__main__":
    main()
